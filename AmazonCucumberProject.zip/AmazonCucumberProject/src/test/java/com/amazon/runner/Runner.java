package com.amazon.runner;

import com.amazon.pages.ProjectSpecificMethods;

import io.cucumber.testng.CucumberOptions;


@CucumberOptions(features = "src/test/resources/featurefiles/AddToCart.feature", glue ="com.amazon.stepdefinitions",

		plugin= {"html:target/cucumber-reports/report.html" },
		       monochrome = true

)

public class Runner extends ProjectSpecificMethods {


	
}
